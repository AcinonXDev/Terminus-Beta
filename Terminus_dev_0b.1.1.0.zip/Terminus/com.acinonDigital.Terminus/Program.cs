﻿//Basic Windows API stuff
using System;
using System.Collections.Generic;
//I have no idea what this does
using System.Linq;
//More Windows stuff
using System.Text;
using System.Threading.Tasks;
using System.IO;
//Creates dialogue boxes, ends up unused
using System.Windows.Forms;
//Creates toolbar, didn't work
using static System.Windows.Forms.ToolStrip;
//A permission level thing I don't need
using System.Security.Permissions;

namespace com.acinonDigital.Terminus
{
    //The main program class
    class Program
    {
        //Almost everything we need before runtime
        static bool runProgram = true;
        static public string command;
        static public string beginInput = "> ";
        static public string cmdArgs;
        public static void Main(string[] args)
        {

            Console.WriteLine("Welcome to Terminus. Enter 'help' to view availible commands");
            //An infinite loop to execute after commands are processed
            while (runProgram == true)
            {
                //creates the text entry carret
                Console.Write(beginInput);
                //Reads command input
                command = Console.ReadLine();
                //Logs the argument in the console
                if (command.Contains("print"))
                {
                    Console.WriteLine("Enter Arguments");
                    Console.Write(beginInput);
                    cmdArgs = Console.ReadLine();
                    Console.WriteLine(cmdArgs);
                }
                //Find a file, then spew it's content on to the console
                else if (command.Contains("read"))
                {
                    Console.WriteLine("Read What?");
                    Console.Write(beginInput);
                    cmdArgs = Console.ReadLine();
                    try
                    {
                        string text = File.ReadAllText(cmdArgs);
                        Console.WriteLine(text);
                    }
                    catch (FileNotFoundException)
                    {
                        Console.WriteLine("File not found, or access is denied");
                    }
                    catch (DirectoryNotFoundException)
                    {
                        Console.WriteLine("Parent Directory not found, or access is denied");
                    }
                    catch (UnauthorizedAccessException)
                    {
                        Console.WriteLine("Cannot access this file or directory, access is denied");
                    }
                    catch (OutOfMemoryException)
                    {
                        Console.WriteLine("File or Directory was too large to load into memory. Please try a smaller File or Directory");
                    }
                }
                //prints about info to the console
                else if (command.Contains("about"))
                {
                    Console.WriteLine("== Terminus Command-Line System Manager ==");
                    Console.WriteLine("Version 0b.1.0.0");
                    Console.WriteLine("Liscensed under CC BY NC SA, 2021");
                    Console.WriteLine("By Acinon Digital Foundation");
                    Console.WriteLine("Description: " + "Terminus is a command - line based system manager, allowing users to view and manipulate various types of files, as well as use other operations on the command - line.");
                }
                //Gets file system partitions and asks if you would like to view more information
                else if (command.Contains("diskinfo"))
                {
                    DriveInfo[] di = DriveInfo.GetDrives();
                    Console.WriteLine("Total Partitions");
                    Console.WriteLine("======================");
                    foreach (DriveInfo items in di)
                    {
                        Console.WriteLine("    " + items.Name);
                    }
                    Console.WriteLine("\nEnter the Partition | ");
                    Console.Write(beginInput);
                    string ch = Console.ReadLine();
                    try
                    {
                        DriveInfo dInfo = new DriveInfo(ch);

                        Console.WriteLine("\n");

                        Console.WriteLine("Disk Name | {0}", dInfo.Name);
                        Console.WriteLine("Total Space | {0}", dInfo.TotalSize);
                        Console.WriteLine("Free Space | {0}", dInfo.TotalFreeSpace);
                        Console.WriteLine("Disk Format | {0}", dInfo.DriveFormat);
                        Console.WriteLine("Volume Label | {0}", dInfo.VolumeLabel);
                        Console.WriteLine("Disk Type | {0}", dInfo.DriveType);
                        Console.WriteLine("Root Directory | {0}", dInfo.RootDirectory);
                        Console.WriteLine("Ready | {0}", dInfo.IsReady);
                    }
                    catch (FileNotFoundException)
                    {
                        Console.WriteLine("File not found, or access is denied");
                    }
                    catch (DirectoryNotFoundException)
                    {
                        Console.WriteLine("Parent Directory not found, or access is denied");
                    }
                    catch (UnauthorizedAccessException)
                    {
                        Console.WriteLine("Cannot access this file or directory, access is denied");
                    }
                }
                //Obtains file system information about directories
                else if (command.Contains("dirinfo"))
                {
                    Console.WriteLine("Get info on which directory?");
                    Console.Write(beginInput);
                    cmdArgs = Console.ReadLine();
                    try
                    {
                        DirectoryInfo di = new DirectoryInfo(cmdArgs);

                        Console.WriteLine("*******Directory Information*******\n\n");
                        Console.WriteLine("Full Name= {0}", di.FullName);
                        Console.WriteLine("Root= {0}", di.Root);
                        Console.WriteLine("Attributes= {0}", di.Attributes);
                        Console.WriteLine("Creation Time= {0}", di.CreationTime);
                        Console.WriteLine("Name= {0}", di.Name);
                        Console.WriteLine("Parent= {0}", di.Parent);
                    }

                    catch (FileNotFoundException)
                    {
                        Console.WriteLine("File not found, or access is denied");
                    }
                    catch (DirectoryNotFoundException)
                    {
                        Console.WriteLine("Parent Directory not found, or access is denied");
                    }
                    catch (UnauthorizedAccessException)
                    {
                        Console.WriteLine("Cannot access this file or directory, access is denied");
                    }
                }
                //Makes a new directory with a specified name
                else if (command.Contains("writedir"))
                {
                    Console.WriteLine("Make a directory where?");
                    Console.Write(beginInput);
                    cmdArgs = Console.ReadLine();

                    DirectoryInfo di = new DirectoryInfo(cmdArgs);
                    Console.WriteLine("What is the name of the directory you want to make?");
                    Console.Write(beginInput);
                    cmdArgs = Console.ReadLine();
                    di.CreateSubdirectory(cmdArgs);
                    Console.WriteLine("Your directory has been succesfully created");
                }
                //Deletes a directory from the hard drive after confirmation
                else if (command.Contains("removedir"))
                {
                    Console.WriteLine("What do you want to remove?");
                    Console.Write(beginInput);
                    cmdArgs = Console.ReadLine();
                    DirectoryInfo di = new DirectoryInfo(cmdArgs);
                    Console.WriteLine("Name: {0}", di.FullName);

                    Console.Write("Are you sure you want to Delete:" + "? " + " (y/n)");
                    if (Console.ReadKey().Key == ConsoleKey.Y)
                    {
                        Directory.Delete(cmdArgs, true);
                        Console.WriteLine("Deleted.....");
                    }
                    if (Console.ReadKey().Key == ConsoleKey.N)
                    {
                        Directory.Delete(@"Z:\canceldelete");
                    }
                    Console.WriteLine("Operation Completed");
                }
                //Lists directory content by obtaining each file and subdirectory
                else if (command.Contains("listdir"))
                {
                    Console.WriteLine("Read which directory?");
                    Console.Write(beginInput);
                    cmdArgs = Console.ReadLine();
                    try
                    {
                        foreach (string folder in Directory.GetDirectories(cmdArgs))
                        {
                            Console.WriteLine("Directory | " + folder);
                        }

                        foreach (string file in Directory.GetFiles(cmdArgs))
                        {
                            Console.WriteLine("File | " + file);
                        }
                    }
                    catch (FileNotFoundException)
                    {
                        Console.WriteLine("File not found, or access is denied");
                    }
                    catch (DirectoryNotFoundException)
                    {
                        Console.WriteLine("Parent Directory not found, or access is denied");
                    }
                    catch (UnauthorizedAccessException)
                    {
                        Console.WriteLine("Cannot access this file or directory, access is denied");
                    }

                }
                else if (command.Contains("clear"))
                {
                    Console.Clear();
                }
                //Move Command. Takes a path from the file system and moves it.
                else if (command.Contains("move"))
                {
                    Console.WriteLine("Move which directory?");
                    Console.Write(beginInput);
                    string path = Console.ReadLine();
                    Console.WriteLine("Move to where?");
                    Console.Write(beginInput);
                    string path2 = Console.ReadLine();
                    try
                    {
                        if (!File.Exists(path))
                        {
                            // This statement ensures that the file is created,
                            // but the handle is not kept.
                            using (FileStream fs = File.Create(path)) { }
                        }

                        // Ensure that the target does not exist.
                        if (File.Exists(path2))
                            File.Delete(path2);

                        // Move the file.
                        File.Move(path, path2);
                        Console.WriteLine("{0} was moved to {1}.", path, path2);

                        // See if the original exists now.
                        if (File.Exists(path))
                        {
                            Console.WriteLine("The directory has veen copied, but the source has not been deleted. Please delete it manually.");
                        }
                        else
                        {
                            Console.WriteLine("Operation Completed Successfully!");
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("The process failed: {0}", e.ToString());
                    }
                }
                //The Help Command. Functions by printing a dialogue to the console.
                else if (command.Contains("help"))
                {
                    Console.WriteLine("== Terminus Help ==");
                    Console.WriteLine("");
                    Console.WriteLine("1- Commands and Syntax");
                    Console.WriteLine("    ");
                    Console.WriteLine("    help- Displays this menu");
                    Console.WriteLine("    print- Prints your argument to the console");
                    Console.WriteLine("    clear- Clears the window");
                    Console.WriteLine("    read- Displays the text contents of a file");
                    Console.WriteLine("    diskinfo- Gives partition info");
                    Console.WriteLine("    dirinfo- Gives info about a directory");
                    Console.WriteLine("    writedir- Makes a new directory in the specified location");
                    Console.WriteLine("    listdir- Lists the file and subdirectory contents of a parent directory");
                    Console.WriteLine("    removedir- Removes a directory");
                    Console.WriteLine("    move- Moves the specified directory to the second specified directory");
                    Console.WriteLine("    about- Shows info about the program and it's developers (me, who is writing this help guide)");
                    Console.WriteLine("Press 'RIGHTARROW' key to go to page 2, Tips and Tricks");
                    Console.Write(beginInput);
                    if (Console.ReadKey().Key == ConsoleKey.RightArrow)
                    {
                        Console.WriteLine("");
                        Console.WriteLine("2- Tips and Tricks");
                        Console.WriteLine("    ");
                        Console.WriteLine("    1. Arguments are not read in the same line as commands. Wait until the command asks you to enter your argument");
                        Console.WriteLine("    2. This console window functions fundamentally the same as a normal console window. You can change the properties in the menu on the window's icon, as well as access other menus");
                        Console.WriteLine("    3. Pay attention to caught errors! It may not catch them the next time, so be cautious, as the console may crash.");
                        Console.WriteLine("    4. This application can be controlled using only keyboard input. Keep your hands off the mouse so that you can type faster");
                        Console.WriteLine("    5. You may use this as an alternative to Windows Explorer, but some features may not be fully implemented, and it won't work flawlessly with windows due to not having full system access.");
                    }
                }
                else
                {
                    Console.WriteLine(beginInput + "Invalid Command");
                }
            }
        }
    }
}
